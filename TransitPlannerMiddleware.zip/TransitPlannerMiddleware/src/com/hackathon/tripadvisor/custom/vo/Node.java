package com.hackathon.tripadvisor.custom.vo;

public class Node {
	private LocationHotelNode node;

	/**
	 * @return the node
	 */
	public LocationHotelNode getNode() {
		return node;
	}

	/**
	 * @param node the node to set
	 */
	public void setNode(LocationHotelNode node) {
		this.node = node;
	}
	
}
