package com.hackathon.common.constants;

public class TransitPlannerConstants {

	public static final String EMIRTAES_HOTEL_LIST_URL = "https://ec2-52-18-199-95.eu-west-1.compute.amazonaws.com:8143/availableCities/1.0/";
	public static final String WEGO_HOTEL_LIST_URL="http://api.wego.com/hotels/api/search/49468260?key=f5305fcfdf8383a8b580&ts_code=efca7";
}
